<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\FoodCategory;
use Faker\Generator as Faker;

$factory->define(FoodCategory::class, function (Faker $faker) {
    return [
        //
    ];
});
