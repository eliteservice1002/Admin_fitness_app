<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\FoodItem;
use Faker\Generator as Faker;

$factory->define(FoodItem::class, function (Faker $faker) {
    return [
        //
    ];
});
